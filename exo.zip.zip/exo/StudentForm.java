import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StudentForm extends JFrame {
    private JTextField nomField, prenomField, contactField, mailField, villeField;
    private JButton validateButton, consultButton;

    public StudentForm() {
        // Créer les composants
        nomField = new JTextField(20);
        prenomField = new JTextField(20);
        contactField = new JTextField(20);
        mailField = new JTextField(20);
        villeField = new JTextField(20);
        validateButton = new JButton("Valider");
        consultButton = new JButton("Consulter");

        // Ajouter des labels et des champs de texte
        JPanel panel = new JPanel();
        panel.add(new JLabel("Nom:"));
        panel.add(nomField);
        panel.add(new JLabel("Prénoms:"));
        panel.add(prenomField);
        panel.add(new JLabel("Contact:"));
        panel.add(contactField);
        panel.add(new JLabel("Mail:"));
        panel.add(mailField);
        panel.add(new JLabel("Ville Provenance:"));
        panel.add(villeField);
        panel.add(validateButton);
        panel.add(consultButton);

        // Ajouter des actions aux boutons
        validateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Connection con = DriverManager.getConnection("liendatabase", "root", "");
                    String query = "INSERT INTO etudiant(NomEtu, PrenomEtu, Contact, Mail, VilleProvenance)VALUES(?,?,?,?,?)";
                    PreparedStatement pst = con.prepareStatement(query);
                    pst.setString(1, nomField.getText());
                    pst.setString(1, prenomField.getText());
                    pst.setString(1, contactField.getText());
                    pst.setString(1, mailField.getText());
                    pst.setString(1, villeField.getText());
                    pst.executeUpdate();

                    JOptionPane.showMessageDialog(null, "Enregistrement réussie");
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Erreur d'enregistrement");
                }
            }
        });

        consultButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new StudentForm().setVisible(true);
            }
        });

        // Configurer le cadre
        setTitle("Enregistrement des étudiants");
        setSize(300, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        add(panel);
        setLocationRelativeTo(null);
    }
}
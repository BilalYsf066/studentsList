import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StudentList extends JFrame {
    public StudentList() {
        String[] columnNames = { "Matricule", "Nom", "Prénoms", "Contact", "Mail", "Ville Provenance" };
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(columnNames);

        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        try {
            Connection con = DriverManager.getConnection("liendatabase", "root", "");
            Statement stmt = con.createStatement();
            ResultSet st = stmt.executeQuery("SELECT*FROM etudiants");

            while (rs.next()) {
                int matricule = rs.getInt("Matricule");
                String nom = rs.getString("NomEtu");
                String prenoms = rs.getString("PrenomsEtu");
                String contact = rs.getString("Contact");
                String mail = rs.getString("Mail");
                String ville = rs.getString("Ville Provenance");

                model.addRow(new Object[] { matricule, nom, prenoms, contact, mail, ville });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        // Configurer le cadre
        setTitle("Enregistrement des étudiants");
        setSize(300, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        add(panel);
        setLocationRelativeTo(null);
    }
}
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginForm extends JFrame {
    private JTextField userField;
    private JPasswordField passField;
    private JButton loginButton;

    public LoginForm() {
        // Créer les composants
        userField = new JTextField(20);
        passField = new JPasswordField(20);
        loginButton = new JButton("Connexion");

        // Ajouter les labels et les champs de textes
        JPanel panel = new JPanel();
        panel.add(new JLabel("Users:"));
        panel.add(userField);
        panel.add(new JLabel("Password:"));
        panel.add(passField);
        panel.add(loginButton);

        // Ajouter des actions aux boutons
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String user = userField.getText();
                String password = new String(passField.getPassword());

                if ("ifri_gl_im2024".equals(user) && "myApp2024".equals(password)) {
                    JOptionPane.showMessageDialog(null, "Connexion réussie");

                    // Ouvrir la fenetre d'enregistrement des étudiants
                    new StrudentForm().setVisible(true);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Utilsateur ou Mot de Passe icorrect");
                }
            }
        });

        // Configurer le cadre
        setTitle("Connexion");
        setSize(350, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(panel);
        setLocationRelativeTo(null);

    }

    public static void main(String[] args) {
        new LoginForm().setVisible(true);
    }
}
